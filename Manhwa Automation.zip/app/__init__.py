"""Manhwa editor application."""

